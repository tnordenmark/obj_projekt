#include "jukebox.h"
using namespace std;

int main()
{
    Jukebox jbox;

    jbox.run();

    return 0;
}

