#ifndef JUKEFUNC_H
#define JUKEFUNC_H

void invalidChoice(int max);
char yesNoMenu();

#endif // JUKEFUNC_H
